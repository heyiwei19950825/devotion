<?php
/**
 * Created by PhpStorm.
 * User: zhoujun
 * Date: 2018/3/31
 * Time: 15:36
 */

namespace app\admin\model;


use think\Model;

class CronTaskLogModel extends Model
{

}