<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/28
 * Time: 17:43
 */
namespace app\admin\model;

use think\Model;

class CateModel extends Model
{

}